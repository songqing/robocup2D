/*

   Z-------------------------------------------------Z
   |                                                 |
   |    File Created By: Amir Tavafi && Nima Nozari  |
   |                                                 |
   |    Date Created:    2010/01/16, 1388/10/26      |
   |                                                 |
   Z-------------------------------------------------Z

*/

#ifndef BHV_MARLIKPASS2_H
#define BHV_MARLIKPASS2_H

#include <rcsc/player/soccer_action.h>
#include <rcsc/player/player_agent.h>

#include <rcsc/geom/vector_2d.h>

// #include <fstream>

// namespace rcsc {

class Bhv_MarlikPass2
    : public rcsc::BodyAction {

private:

   rcsc::Vector2D opp[20];
   rcsc::Vector2D tmm[20];
   rcsc::AngleDeg tAngle[20];

   int receiver[20];
   int oppNo[20];

   int oCount[20];
   int tCount[20];

   const rcsc::PlayerType * oppPlayerType[20];
   const rcsc::PlayerType * tmmPlayerType[20];

   int oMax;
   int tMax;
    int i;

public:

//     ofstream out;

    Bhv_MarlikPass2();

    ~Bhv_MarlikPass2();

//     int logFlag;
    int sign ( float n );
    rcsc::Vector2D getSortedTmm ( rcsc::PlayerAgent * agent, rcsc::Vector2D point, int rank , int &num, int maxCount);
    int cycles( rcsc::PlayerAgent * agent, rcsc::Vector2D target, float speed, int i, rcsc::Vector2D o[], int x );
//    int cycles2( rcsc::PlayerAgent * agent, rcsc::Vector2D target, float speed, int i, rcsc::Vector2D o[], int x );
    int crossCycles( rcsc::PlayerAgent * agent, rcsc::Vector2D target, float speed, rcsc::Vector2D o[] );
    int leadingCycles( rcsc::PlayerAgent * agent, rcsc::Vector2D target, float speed, int tmmNum );
//    int throughCycles( rcsc::PlayerAgent * agent, rcsc::Vector2D target, float speed, int i, rcsc::Vector2D o[] );
    int throughCycles( rcsc::PlayerAgent * agent, rcsc::Vector2D target, float speed, rcsc::Vector2D tmmPos );
    int selfCyclesSRP( rcsc::PlayerAgent * agent, rcsc::Vector2D target, float speed );

    bool canPassToNo ( rcsc::PlayerAgent * agent, int no );
//     bool SelfPass( rcsc::PlayerAgent * agent);
    bool DirectPass( rcsc::PlayerAgent * agent, rcsc::Vector2D & target );
//    bool DirectPass2( rcsc::PlayerAgent * agent, rcsc::Vector2D & target );
    bool LeadingPass( rcsc::PlayerAgent * agent, rcsc::Vector2D & target );
    bool LeadingPass2011( rcsc::PlayerAgent * agent, rcsc::Vector2D & targetzz );
    bool ThroughPass( rcsc::PlayerAgent * agent, rcsc::Vector2D & target );
    bool PowerfulThroughPass( rcsc::PlayerAgent * agent, rcsc::Vector2D & target );
    bool PowerfulThroughPass2011( rcsc::PlayerAgent * agent, rcsc::Vector2D & target );
    bool CrossPass( rcsc::PlayerAgent * agent, rcsc::Vector2D & target );
    bool BrainCross2( rcsc::PlayerAgent * agent, rcsc::Vector2D & target );
    bool SRPD( rcsc::PlayerAgent * agent );
    bool SRPtoCenter( rcsc::PlayerAgent * agent );
    bool SRPtoOutside( rcsc::PlayerAgent * agent );
    bool DKhBClear( rcsc::PlayerAgent * agent );

    bool execute( rcsc::PlayerAgent * agent );

//   void setLog()
//   {
//        if (!logFlag)
//        {
//           int num = agent->world().self().unum();
//           char name[10];
//           strcpy(name, "log");
//           name[3] = num + '0';
//           name[4] = 0;
//           out.open(name);
//        }
//         logFlag = true;
//
//   }

};

// }

#endif

/*

   Z----------------------------------Z
   |                                  |
   |    File Created By: Amir Tavafi  |
   |                                  |
   |    Date Created:    2009/11/18,  |
   |                     1388/08/27   |
   |                                  |
   Z----------------------------------Z

*/

#ifndef BHV_MARLIKSHOOT_H
#define BHV_MARLIKSHOOT_H

#include <rcsc/player/soccer_action.h>

#include <rcsc/geom/vector_2d.h>

// namespace rcsc {

class Bhv_MarlikShoot
    : public rcsc::BodyAction {

private:

    bool canScore( rcsc::PlayerAgent * agent, const rcsc::Vector2D & shootTarget,
                   const double one_step_speed );

public:

    Bhv_MarlikShoot()
      { }


    bool execute( rcsc::PlayerAgent * agent );

};

// }

#endif

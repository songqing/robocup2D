/*

   Z-------------------------------------------------Z
   |                                                 |
   |    File Created By: Amir Tavafi && Nima Nozari  |
   |                                                 |
   |    Date Created:    2010/01/16, 1388/10/26      |
   |                                                 |
   Z-------------------------------------------------Z

*/

#ifndef BHV_MARLIKPASS_H
#define BHV_MARLIKPASS_H

#include <rcsc/player/soccer_action.h>

#include <rcsc/geom/vector_2d.h>

// #include <fstream>

// namespace rcsc {

class Bhv_MarlikPass
    : public rcsc::BodyAction {

private:

   rcsc::Vector2D opp[20];
   rcsc::Vector2D tmm[20];
   rcsc::AngleDeg tAngle[20];

   int receiver[20];

   int oCount[20];
   int tCount[20];

   int oMax;
   int tMax;

public:

//     ofstream out;

    Bhv_MarlikPass();

    ~Bhv_MarlikPass();

//     int logFlag;
    int sign ( float n );
    int cycles( rcsc::PlayerAgent * agent, rcsc::Vector2D target, float speed, int i, rcsc::Vector2D o[] );
    int throughCycles( rcsc::PlayerAgent * agent, rcsc::Vector2D target, float speed, int i, rcsc::Vector2D o[] );

    int cycles2( rcsc::PlayerAgent * agent, rcsc::Vector2D target, float speed, int i, rcsc::Vector2D o[], float *x, float *y);
    rcsc::Vector2D finalPoint( rcsc::PlayerAgent * agent, float dir, float speed);

//     bool SelfPass( rcsc::PlayerAgent * agent);
    bool DirectPass( rcsc::PlayerAgent * agent, rcsc::Vector2D & target );
    bool LeadingPass( rcsc::PlayerAgent * agent, rcsc::Vector2D & target );
    bool ThroughPass( rcsc::PlayerAgent * agent, rcsc::Vector2D & target );
    bool CrossPass( rcsc::PlayerAgent * agent, rcsc::Vector2D & target );
    bool BrainCross( rcsc::PlayerAgent * agent, rcsc::Vector2D & target );
    bool BrainCross2( rcsc::PlayerAgent * agent, rcsc::Vector2D & target );
    bool SRPD( rcsc::PlayerAgent * agent );

    bool execute( rcsc::PlayerAgent * agent );

//   void setLog()
//   {
//        if (!logFlag)
//        {
//           int num = agent->world().self().unum();
//           char name[10];
//           strcpy(name, "log");
//           name[3] = num + '0';
//           name[4] = 0;
//           out.open(name);
//        }
//         logFlag = true;
// 
//   }

};

// }

#endif

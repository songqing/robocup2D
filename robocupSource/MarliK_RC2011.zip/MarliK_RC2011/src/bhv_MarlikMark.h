/*

   Z----------------------------------Z
   |                                  |
   |    File Created By: Amir Tavafi  |
   |                                  |
   |    Date Created:    2009/11/20,  |
   |                     1388/08/29   |
   |                                  |
   Z----------------------------------Z

*/

#ifndef BHV_MARLIKMARK_H
#define BHV_MARLIKMARK_H

#include <rcsc/geom/vector_2d.h>
#include <rcsc/player/soccer_action.h>

class Bhv_MarlikMark
    : public rcsc::SoccerBehavior {

private:
    const rcsc::Vector2D HOME_POS;

public:

      Bhv_MarlikMark( const rcsc::Vector2D & home_pos )
        : HOME_POS( home_pos )
      { }

      bool execute( rcsc::PlayerAgent * agent );

};

#endif
